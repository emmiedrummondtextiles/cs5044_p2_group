// Export the function to draw a bar chart showing time signature distribution
export function drawBarChart2(data) {
  // Define chart margins and dimensions
  const margin = { top: 40, right: 20, bottom: 60, left: 60 };
  const width = 800 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;

  // Data preprocessing: Replace 'NA' with 'Unknown' for time_signature
  data = data.map(d => ({
    ...d,
    time_signature: d.time_signature === 'NA' ? 'Unknown' : d.time_signature
  }));

  // Extract unique years and populate the dropdown menu
  const years = ['All', ...Array.from(new Set(data.map(d => d.Year))).sort()];
  const yearSelector1 = d3.select('#yearSelector1');
  yearSelector1.selectAll('option')
    .data(years)
    .enter()
    .append('option')
    .attr('value', d => d)
    .text(d => d);

  // When user changes the selected year, update the chart
  yearSelector1.on('change', function () {
    updateChart(this.value);
  });

  // Draw the chart with all years selected by default
  updateChart('All');

  // Function to draw or update the chart based on the selected year
  function updateChart(selectedYear) {
    // Filter the data based on selected year
    const filteredData = selectedYear === 'All'
      ? data
      : data.filter(d => d.Year === +selectedYear);

    // Count the number of occurrences of each time_signature
    const timeSignatureCounts = d3.rollups(
      filteredData,
      v => v.length,
      d => d.time_signature
    ).sort((a, b) => d3.descending(a[1], b[1])); // Sort by count descending

    // Select and clear the container for redrawing
    const container = d3.select('#barChart2');
    container.selectAll('*').remove();

    // If no data available, show a message
    if (timeSignatureCounts.length === 0) {
      container.html('<p>No data available for this year.</p>');
      return;
    }

    // Create an SVG element
    const svg = container.append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Define x-axis scale (categorical: time_signature)
    const x = d3.scaleBand()
      .domain(timeSignatureCounts.map(d => d[0]))
      .range([0, width])
      .padding(0.2);

    // Define y-axis scale (linear: counts)
    const y = d3.scaleLinear()
      .domain([0, d3.max(timeSignatureCounts, d => d[1])])
      .nice()
      .range([height, 0]);

    // Draw x-axis with rotated labels
    svg.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .style('text-anchor', 'end');

    // Draw y-axis
    svg.append('g').call(d3.axisLeft(y));

    // Use color scale for the bars
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    // Create bars
    const bars = svg.selectAll('rect')
      .data(timeSignatureCounts)
      .enter()
      .append('rect')
      .attr('x', d => x(d[0]))
      .attr('y', d => y(d[1]))
      .attr('width', x.bandwidth())
      .attr('height', d => height - y(d[1]))
      .attr('fill', d => colorScale(d[0]));

    // Create a tooltip (only once)
    const tooltip = svg.append('text')
      .attr('id', 'tooltip')
      .style('font-size', '12px')
      .style('font-weight', 'bold')
      .style('fill', 'black')
      .style('display', 'none');

    // Show tooltip on hover
    bars.on('mouseover', function (event, d) {
      tooltip
        .attr('x', x(d[0]) + x.bandwidth() / 2)
        .attr('y', y(d[1]) - 10)
        .attr('text-anchor', 'middle')
        .text(d[1])
        .style('display', 'block');
    }).on('mouseout', () => tooltip.style('display', 'none'));

    // Add chart title
    svg.append('text')
      .attr('x', width / 2)
      .attr('y', -10)
      .attr('text-anchor', 'middle')
      .style('font-size', '16px')
      .text(`Time Signature Distribution - Year ${selectedYear === 'All' ? 'All Years' : selectedYear}`);
  }
}

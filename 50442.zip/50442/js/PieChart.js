export function drawPieChart(data) {
  // Set up margins and dimensions for the chart
  const margin = { top: 40, right: 20, bottom: 60, left: 60 };
  const width = 800 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;
  const radius = Math.min(width, height) / 2;

  // Data preprocessing: replace 'NA' with 'Unknown' and '0' or '1' with 'Others' and 'English' respectively
  data = data.map(d => ({
    ...d,
    Song_In_English:
      d.Song_In_English === 'NA' ? 'Unknown' :
      d.Song_In_English === 0 ? 'Others' :
      d.Song_In_English === 1 ? 'English' : d.Song_In_English
  }));

  // Create color scale using predefined D3 color scheme
  const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

  // Clear any previous charts from the container
  d3.select('#pieChart').selectAll('*').remove();

  // Create an SVG container for the pie chart
  const svg = d3.select('#pieChart')
    .append('svg')
    .attr('width', width + margin.left + margin.right)
    .attr('height', height + margin.top + margin.bottom)
    .append('g')
    .attr('transform', `translate(${width / 2 + margin.left}, ${height / 2 + margin.top})`);

  // Pie chart and arc generators
  const pie = d3.pie().value(d => d[1]);
  const arc = d3.arc().outerRadius(radius - 10).innerRadius(0);

  // Tooltip element that will be shown on hover
  const tooltip = d3.select('#pieChart')
    .append('div')
    .attr('class', 'tooltip')
    .style('position', 'absolute')
    .style('visibility', 'hidden')
    .style('background', 'rgba(0, 0, 0, 0.7)')
    .style('color', '#fff')
    .style('padding', '5px')
    .style('border-radius', '3px')
    .style('font-size', '12px');

  // Function to render pie chart arcs and update on data change
  function renderArcs(counts) {
    svg.selectAll('.arc').remove();  // Remove old arcs

    // Create new arcs based on data
    const arcs = svg.selectAll('.arc')
      .data(pie(counts))
      .enter()
      .append('g')
      .attr('class', 'arc');

    // Append path elements for the arcs
    arcs.append('path')
      .attr('d', arc)
      .attr('fill', d => colorScale(d.data[0]))
      .attr('stroke', 'white')
      .attr('stroke-width', 1);

    // Add labels to each arc
    arcs.append('text')
      .attr('transform', d => `translate(${arc.centroid(d)})`)
      .attr('dy', '.35em')
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .style('font-weight', 'bold')
      .text(d => d.data[0]);

    // Tooltip behavior for hover interaction
    arcs.on('mouseover', (event, d) => {
      tooltip.style('visibility', 'visible').html(`${d.data[0]}: ${d.data[1]}`);
    })
    .on('mousemove', event => {
      tooltip.style('top', `${event.pageY + 10}px`).style('left', `${event.pageX + 10}px`);
    })
    .on('mouseout', () => {
      tooltip.style('visibility', 'hidden');
    });
  }

  // Initial data aggregation and rendering of the pie chart
  const initialCounts = d3.rollups(data, v => v.length, d => d.Song_In_English)
    .sort((a, b) => d3.descending(a[1], b[1]));

  renderArcs(initialCounts);

  // Add chart title
  svg.append('text')
    .attr('x', 0)
    .attr('y', -radius - 10)
    .attr('text-anchor', 'middle')
    .style('font-size', '16px')
    .text('Song In English Distribution');

  // Create year filter dropdown
  const years = Array.from(new Set(data.map(d => d.Year))).sort((a, b) => a - b);

  const yearFilter = d3.select('#yearFilter');
  const yearSelect = yearFilter.append('select')
    .attr('id', 'yearSelect')
    .on('change', function () {
      const selected = this.value;
      const filteredData = selected === 'All' ? data : data.filter(d => d.Year === +selected);

      const counts = d3.rollups(filteredData, v => v.length, d => d.Song_In_English)
        .sort((a, b) => d3.descending(a[1], b[1]));

      renderArcs(counts);  // Update chart with filtered data
    });

  // Add options for each year to the dropdown
  yearSelect.append('option').attr('value', 'All').text('All');
  yearSelect.selectAll('option')
    .data(years)
    .enter()
    .append('option')
    .attr('value', d => d)
    .text(d => d);
}
